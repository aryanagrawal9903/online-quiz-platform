from django.apps import AppConfig



class McqConfig(AppConfig):
    name = 'mcq'
